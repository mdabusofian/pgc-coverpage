কর্ণফুলী ব্লাড হাব — Complete Release v6 (PWA Ready)

১) প্যাকেজে যা আছে
site/ ফোল্ডার:
- index.html — Homepage
- about.html — About
- donor-registration.html — Login ছাড়া Donor Registration
- donor_registration.html — পুরোনো URL থেকে নতুন Registration পেজে Redirect
- application-status.html — Application Status, Card Download ও Rejected Application Resubmission
- all-donors.html — Supabase Public Donor List
- blood_requests.html — Public Blood Request List + Request Form
- verify-donor.html — QR Verification
- download.html — PWA Install Guide
- admin.html — একটিমাত্র Unified Admin Dashboard

sql/ ফোল্ডার:
- kbh_admin_dashboard_patch.sql
- kbh_admin_modules.sql
- kbh_public_pages_workflow.sql
- kbh_card_phone_visibility_patch.sql

supabase/ ফোল্ডার:
- config.toml
- functions/invite-staff/index.ts

২) আপনার Supabase SQL-এর অবস্থা
আপনি নিশ্চিত করেছেন যে নিচের চারটি SQL-ই Supabase SQL Editor-এ সফলভাবে Run হয়েছে এবং প্রতিবার “Success. No rows returned” এসেছে:
1. kbh_admin_dashboard_patch.sql
2. kbh_admin_modules.sql
3. kbh_public_pages_workflow.sql
4. kbh_card_phone_visibility_patch.sql

অতএব একই প্রজেক্টে এই চারটি SQL আবার Run করার প্রয়োজন নেই। ZIP-এ SQL ফাইলগুলো রেফারেন্স/নতুন সেটআপের জন্য রাখা হয়েছে। নতুন কোনো Supabase project-এ সেটআপ করলে আগে মূল migration `kbh_public_donor_workflow.sql` সফল করতে হবে; এরপর `kbh_admin_modules.sql`, `kbh_admin_dashboard_patch.sql`, `kbh_public_pages_workflow.sql`, এবং সবশেষে `kbh_card_phone_visibility_patch.sql` চালাতে হবে। মূল migration এই ZIP-এ নেই, কারণ আপনার আগের সেটআপে সেটি ইতিমধ্যে চালানো হয়েছিল।

৩) এই Release-এর গুরুত্বপূর্ণ Workflow
- Donor Registration-এ Login/Account লাগে না; নতুন আবেদন Pending থাকে।
- Admin/অনুমতিপ্রাপ্ত Staff যাচাই করে Approve বা Reject করতে পারে। Reject করলে কারণ দিতে হয়।
- Rejected আবেদন Application Number ও আগের মোবাইল দিয়ে যাচাই করে সংশোধনসহ পুনরায় Pending করা যায়।
- Approved Donor-এর Card Number তৈরি হয়; Application Status পেজ থেকে Application Number + নিবন্ধিত মোবাইল দিয়ে কার্ড দেখা যায়।
- Card Page-এ “কার্ডে মোবাইল নম্বর দেখান” অপশন দিয়ে নম্বরসহ বা নম্বর ছাড়া PNG ডাউনলোড করা যায়।
- Card পুনরায় পেতে Card Number + নিবন্ধিত মোবাইল—দুটিই দিতে হয়।
- Public Donor List-এ কেবল Approved এবং Public Listing সম্মত ডোনার দেখায়। ফোন নম্বর কেবল আলাদা Public Contact সম্মতি থাকলে API থেকে আসে।
- Public Donor List-এ মোবাইল প্রকাশ-সম্মতি সংক্রান্ত অপ্রয়োজনীয় লেখা দেখানো হয় না।
- সর্বশেষ রক্তদানের তারিখ কেবল Verified donation record থেকে দেখানো হয়।
- Public Blood Request জমা হলে Pending থাকে; Admin Live করলে এবং নম্বর প্রকাশের সম্মতি থাকলেই public list-এ আসে।
- একটিমাত্র Unified Admin Dashboard আছে; আলাদা Super Admin Dashboard নেই।
- Browser-side code-এ Supabase service_role key রাখা যাবে না।

৪) Website Deploy
`site/` ফোল্ডারের HTML ফাইলগুলো আপনার GitHub website repository-এর root directory-তে কপি/replace করুন। এই ZIP-এ PWA-এর সব প্রয়োজনীয় ফাইল যুক্ত আছে: `pwa.js`, `manifest.webmanifest`, `sw.js` এবং `icons/` ফোল্ডার। এগুলো অবশ্যই একসঙ্গে আপলোড করুন।

সব HTML পেজ এবং `manifest.webmanifest`, `pwa.js`, `sw.js` একই root directory-তে রাখুন। `icons/` ফোল্ডারটিও root-এ আপলোড করুন। `donor_registration.html` পুরোনো link/bookmark-এর compatibility redirect হিসেবে থাকবে। নতুন link-এ `donor-registration.html` ব্যবহার করুন।

PWA ইনস্টল: GitHub Pages-এ HTTPS চালু থাকতে হবে। Android Chrome-এ সাইট খুলে ⋮ → Install app চাপুন। কম্পিউটার Chrome-এ address bar-এর Install icon অথবা ⋮ → Cast, save and share → Install page as app ব্যবহার করুন। PWA-এর জন্য APK ডাউনলোড প্রয়োজন নেই। `sw.js` offline app shell cache করে; Supabase-এর live ডেটা/অনলাইন কাজের জন্য ইন্টারনেট লাগবে।

৫) Deploy-এর পর Live Test Checklist
- Donor Registration: Login ছাড়া আবেদন → Application Number পাওয়া → Status lookup
- Rejected আবেদন: কারণ দেখা → তথ্য সংশোধন → একই Application Number দিয়ে পুনরায় Pending
- Admin: Pending donor approve/reject → reject reason বাধ্যতামূলক → approved হলে Card issue
- ID Card: Application Status থেকে মোবাইলসহ/মোবাইল ছাড়া PNG download → QR scan → valid/revoked status
- Public Donor List: Listing consent ছাড়া নাম না আসা; Contact consent ছাড়া ফোন না আসা
- Public Blood Request: form submit → Pending → Admin consent যাচাই করে Publish → public list-এ দেখা
- Donation: Pending record add → Verify/Reject
- Staff: invite email → permission grant → staff login → assigned module only

যাচাইয়ের সীমাবদ্ধতা
এই workspace থেকে আপনার live Supabase project-এ database query, donor approval, email invite, PNG download বা real QR scan চালানো সম্ভব হয়নি। ZIP integrity test এবং HTML পেজগুলোর inline JavaScript Node.js syntax check করা হয়েছে; এগুলো live backend বা browser interaction test-এর বিকল্প নয়।
