-- Karnaphuli Blood Hub | Unified Admin Dashboard RLS patch
-- Prerequisite: kbh_public_donor_workflow.sql and kbh_admin_modules.sql
-- Allows a permitted Admin/Staff account to view staff role assignments only
-- when it has the dedicated staff.roles.manage permission.

begin;

drop policy if exists "roles_select_own_or_super" on public.user_roles;
drop policy if exists "roles_select_own_or_manage" on public.user_roles;
create policy "roles_select_own_or_manage" on public.user_roles
for select to authenticated
using (
  user_id = (select auth.uid())
  or (select private.has_permission('staff.roles.manage'))
);


-- Do not publish a blood request unless the caller explicitly consented to
-- public display of the contact number.
create or replace function public.admin_update_blood_request(
  p_request_id uuid,
  p_new_status text,
  p_reason text default null
)
returns public.request_status
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor uuid := auth.uid();
  v_old public.request_status;
  v_created_by uuid;
  v_contact_public_consent boolean;
  v_new public.request_status;
  v_reason text := nullif(pg_catalog.btrim(coalesce(p_reason,'')),'');
begin
  if v_actor is null or not private.has_permission('requests.manage') then
    raise exception 'You do not have permission to manage blood requests';
  end if;
  if p_new_status not in ('live','closed','rejected') then raise exception 'Invalid request status'; end if;
  if p_new_status='rejected' and v_reason is null then raise exception 'Reject reason is required'; end if;

  select request_status,created_by,contact_public_consent
    into v_old,v_created_by,v_contact_public_consent
  from public.blood_requests where id=p_request_id for update;
  if not found then raise exception 'Blood request not found'; end if;
  if p_new_status='live' and not coalesce(v_contact_public_consent,false) then
    raise exception 'Contact publication consent is required before publishing this request';
  end if;

  v_new := p_new_status::public.request_status;
  if v_old='pending' and v_new not in ('live','rejected','closed') then raise exception 'Invalid transition'; end if;
  if v_old='live' and v_new not in ('closed') then raise exception 'Live request can only be closed'; end if;
  if v_old='closed' and v_new not in ('live') then raise exception 'Closed request can only be reopened'; end if;
  if v_old='rejected' then raise exception 'Rejected request cannot be changed'; end if;

  update public.blood_requests set request_status=v_new,reviewed_by=v_actor,reviewed_at=now()
  where id=p_request_id;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(v_actor,'blood_request.status_changed','blood_request',p_request_id::text,
    pg_catalog.jsonb_build_object('old_status',v_old,'new_status',v_new,'reason',v_reason));

  if v_created_by is not null then
    insert into public.notifications(user_id,title,body,notification_type)
    values(v_created_by,'Blood Request আপডেট',
      'আপনার Blood Request-এর বর্তমান অবস্থা: '||v_new::text||case when v_reason is not null then '। কারণ: '||v_reason else '' end,
      'blood_request');
  end if;
  return v_new;
end;
$$;
revoke all on function public.admin_update_blood_request(uuid,text,text) from public,anon;
grant execute on function public.admin_update_blood_request(uuid,text,text) to authenticated;


-- Distinguish privileged Admin accounts from delegated Staff managers.
create or replace function private.is_admin_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.user_id=(select auth.uid()) and ur.role in ('admin','super_admin')
  );
$$;
revoke all on function private.is_admin_user() from public,anon;
grant execute on function private.is_admin_user() to authenticated;

-- Staff may manage ordinary permissions for OTHER staff members, but cannot
-- grant themselves permissions or delegate privileged administration powers.
drop policy if exists "employee_permissions_insert_admin" on public.employee_permissions;
drop policy if exists "employee_permissions_delete_admin" on public.employee_permissions;
drop policy if exists "employee_permissions_insert_delegated" on public.employee_permissions;
drop policy if exists "employee_permissions_delete_delegated" on public.employee_permissions;
create policy "employee_permissions_insert_delegated" on public.employee_permissions
for insert to authenticated
with check (
  (select private.has_permission('staff.permissions.manage'))
  and (
    (select private.is_admin_user())
    or (
      user_id <> (select auth.uid())
      and permission_key not in ('staff.permissions.manage','staff.roles.manage','security.logs.view','settings.manage')
    )
  )
);
create policy "employee_permissions_delete_delegated" on public.employee_permissions
for delete to authenticated
using (
  (select private.has_permission('staff.permissions.manage'))
  and (
    (select private.is_admin_user())
    or (
      user_id <> (select auth.uid())
      and permission_key not in ('staff.permissions.manage','staff.roles.manage','security.logs.view','settings.manage')
    )
  )
);

notify pgrst, 'reload schema';

commit;
