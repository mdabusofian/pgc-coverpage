-- Karnaphuli Blood Hub | Admin Dashboard modules migration
-- Prerequisite: run kbh_public_donor_workflow.sql successfully first.
-- Safe to run once; uses CREATE OR REPLACE / IF NOT EXISTS and policy replacement.
begin;

-- Admins can use the unified Admin Dashboard; staff remain permission-scoped.
create or replace function private.has_permission(permission_name text)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.user_id = (select auth.uid())
      and (
        ur.role in ('super_admin','admin')
        or (
          ur.role = 'staff'
          and exists (
            select 1 from public.employee_permissions ep
            where ep.user_id = ur.user_id
              and ep.permission_key = permission_name
          )
        )
      )
  );
$$;
grant execute on function private.has_permission(text) to authenticated;

insert into public.permission_catalog(permission_key,label,description) values
('notifications.send','Send notifications','Send in-app messages to Auth-linked donors')
on conflict(permission_key) do nothing;

-- Staff permission visibility and management through the Admin Dashboard.
drop policy if exists "employee_permissions_select" on public.employee_permissions;
create policy "employee_permissions_select" on public.employee_permissions
for select to authenticated
using ((select private.has_permission('staff.permissions.manage')) or user_id=(select auth.uid()));

drop policy if exists "employee_permissions_insert_super" on public.employee_permissions;
create policy "employee_permissions_insert_admin" on public.employee_permissions
for insert to authenticated
with check ((select private.has_permission('staff.permissions.manage')));

drop policy if exists "employee_permissions_delete_super" on public.employee_permissions;
create policy "employee_permissions_delete_admin" on public.employee_permissions
for delete to authenticated
using ((select private.has_permission('staff.permissions.manage')));

-- Allow Admin role (not just Super Admin) to view and manage settings.
drop policy if exists "site_settings_public_read" on public.site_settings;
create policy "site_settings_public_read" on public.site_settings
for select to anon, authenticated
using (is_public = true or (select private.has_permission('settings.manage')));

drop policy if exists "site_settings_admin_insert" on public.site_settings;
create policy "site_settings_admin_insert" on public.site_settings
for insert to authenticated
with check ((select private.has_permission('settings.manage')));

drop policy if exists "site_settings_admin_update" on public.site_settings;
create policy "site_settings_admin_update" on public.site_settings
for update to authenticated
using ((select private.has_permission('settings.manage')))
with check ((select private.has_permission('settings.manage')));

-- Donation record creation: every new record starts Pending.
create or replace function public.admin_add_donation_record(
  p_donor_profile_id uuid,
  p_donated_on date,
  p_facility text default null,
  p_notes text default null
)
returns uuid
language plpgsql security definer set search_path = ''
as $$
declare
  v_id uuid;
  v_user_id uuid;
begin
  if auth.uid() is null or not private.has_permission('donations.verify') then
    raise exception 'You do not have permission to add donation records';
  end if;
  if p_donated_on is null or p_donated_on > current_date then
    raise exception 'Valid donation date is required';
  end if;
  select user_id into v_user_id from public.donor_profiles
  where id=p_donor_profile_id and donor_status='approved' for update;
  if not found then raise exception 'Approved donor not found'; end if;

  insert into public.donation_records(
    donor_user_id, donor_profile_id, donated_on, facility, notes,
    verification_status, submitted_by
  ) values (
    v_user_id, p_donor_profile_id, p_donated_on,
    nullif(pg_catalog.btrim(coalesce(p_facility,'')),''),
    nullif(pg_catalog.btrim(coalesce(p_notes,'')),''),
    'pending', auth.uid()
  ) returning id into v_id;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(auth.uid(),'donation.created','donation_record',v_id::text,
    pg_catalog.jsonb_build_object('donor_profile_id',p_donor_profile_id,'donated_on',p_donated_on));
  return v_id;
end;
$$;
revoke all on function public.admin_add_donation_record(uuid,date,text,text) from public,anon;
grant execute on function public.admin_add_donation_record(uuid,date,text,text) to authenticated;

-- Donation date validation follows Bangladesh local calendar date.
ALTER FUNCTION public.admin_add_donation_record(uuid,date,text,text) SET timezone TO 'Asia/Dhaka';

-- Donation verification/rejection with audit log and latest verified date sync.
create or replace function public.admin_review_donation(
  p_donation_record_id uuid,
  p_decision text,
  p_reason text default null
)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_actor uuid := auth.uid();
  v_donor_profile_id uuid;
  v_user_id uuid;
  v_old_status public.donation_status;
  v_donated_on date;
  v_reason text := nullif(pg_catalog.btrim(coalesce(p_reason,'')),'');
begin
  if v_actor is null or not private.has_permission('donations.verify') then
    raise exception 'You do not have permission to verify donations';
  end if;
  if p_decision not in ('verified','rejected') then raise exception 'Invalid decision'; end if;
  if p_decision='rejected' and v_reason is null then raise exception 'Reject reason is required'; end if;

  select donor_profile_id, donor_user_id, verification_status, donated_on
  into v_donor_profile_id,v_user_id,v_old_status,v_donated_on
  from public.donation_records where id=p_donation_record_id for update;
  if not found then raise exception 'Donation record not found'; end if;
  if v_old_status <> 'pending' then raise exception 'Only Pending donation records can be reviewed'; end if;

  update public.donation_records
  set verification_status=p_decision::public.donation_status,
      verified_by=v_actor, verified_at=now(),
      notes=case when v_reason is not null then concat_ws(E'\n',notes,'Admin review: '||v_reason) else notes end
  where id=p_donation_record_id;

  if p_decision='verified' and v_donor_profile_id is not null then
    update public.donor_profiles dp
    set last_donation_date=(
      select max(dr.donated_on) from public.donation_records dr
      where dr.donor_profile_id=v_donor_profile_id and dr.verification_status='verified'
    )
    where dp.id=v_donor_profile_id;
  end if;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(v_actor,'donation.'||p_decision,'donation_record',p_donation_record_id::text,
    pg_catalog.jsonb_build_object('donor_profile_id',v_donor_profile_id,'donated_on',v_donated_on,'reason',v_reason));

  if v_user_id is not null then
    insert into public.notifications(user_id,title,body,notification_type)
    values(v_user_id,
      case when p_decision='verified' then 'রক্তদানের তথ্য Verified' else 'রক্তদানের তথ্য Reject' end,
      case when p_decision='verified' then 'আপনার রক্তদানের তথ্য যাচাই করে যুক্ত করা হয়েছে।' else v_reason end,
      'donation');
  end if;
end;
$$;
revoke all on function public.admin_review_donation(uuid,text,text) from public,anon;
grant execute on function public.admin_review_donation(uuid,text,text) to authenticated;

-- Admin-created blood requests also use a validated RPC and write an audit log.
create or replace function public.admin_create_blood_request(
  p_blood_group text,
  p_units smallint,
  p_patient_name text,
  p_hospital text,
  p_district text,
  p_area text,
  p_contact_phone text,
  p_needed_by date,
  p_notes text default null,
  p_contact_public_consent boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor uuid := auth.uid();
  v_id uuid;
  v_phone text := pg_catalog.regexp_replace(coalesce(p_contact_phone,''), '[^0-9]', '', 'g');
  v_notes text := nullif(pg_catalog.btrim(coalesce(p_notes,'')), '');
begin
  if v_actor is null or not private.has_permission('requests.manage') then
    raise exception 'You do not have permission to create blood requests';
  end if;
  if coalesce(p_blood_group,'') not in ('A+','A-','B+','B-','AB+','AB-','O+','O-') then
    raise exception 'সঠিক রক্তের গ্রুপ নির্বাচন করুন';
  end if;
  if p_units is null or p_units < 1 or p_units > 10 then
    raise exception '১ থেকে ১০ ব্যাগের মধ্যে পরিমাণ দিন';
  end if;
  if pg_catalog.length(pg_catalog.btrim(coalesce(p_patient_name,''))) < 2 then
    raise exception 'রোগীর নাম লিখুন';
  end if;
  if pg_catalog.length(pg_catalog.btrim(coalesce(p_hospital,''))) < 2 then
    raise exception 'হাসপাতালের নাম লিখুন';
  end if;
  if coalesce(pg_catalog.btrim(p_district),'')='' or coalesce(pg_catalog.btrim(p_area),'')='' then
    raise exception 'জেলা ও এলাকা পূরণ করুন';
  end if;
  if v_phone !~ '^01[0-9]{9}$' then
    raise exception 'সঠিক ১১ সংখ্যার বাংলাদেশি মোবাইল নম্বর দিন';
  end if;
  if p_needed_by is null or p_needed_by < current_date then
    raise exception 'আজ অথবা পরবর্তী তারিখ নির্বাচন করুন';
  end if;
  if coalesce(p_contact_public_consent,false) is not true then
    raise exception 'যোগাযোগের নম্বর প্রকাশের সম্মতি আবশ্যক';
  end if;
  if pg_catalog.length(coalesce(v_notes,'')) > 160 then
    raise exception 'অতিরিক্ত তথ্য ১৬০ অক্ষরের মধ্যে রাখুন';
  end if;

  insert into public.blood_requests(
    created_by,blood_group,units,patient_name,hospital,district,area,
    contact_phone,needed_by,notes,contact_public_consent,request_status
  ) values (
    v_actor,p_blood_group,p_units,pg_catalog.btrim(p_patient_name),
    pg_catalog.btrim(p_hospital),pg_catalog.btrim(p_district),pg_catalog.btrim(p_area),
    v_phone,p_needed_by,v_notes,true,'pending'
  ) returning id into v_id;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(v_actor,'blood_request.created','blood_request',v_id::text,
    pg_catalog.jsonb_build_object('source','admin_dashboard','blood_group',p_blood_group,
      'units',p_units,'district',pg_catalog.btrim(p_district),'area',pg_catalog.btrim(p_area)));
  return v_id;
end;
$$;
revoke all on function public.admin_create_blood_request(text,smallint,text,text,text,text,text,date,text,boolean) from public,anon;
grant execute on function public.admin_create_blood_request(text,smallint,text,text,text,text,text,date,text,boolean) to authenticated;

-- Admin-created blood request date validation follows Bangladesh local date.
ALTER FUNCTION public.admin_create_blood_request(text,smallint,text,text,text,text,text,date,text,boolean) SET timezone TO 'Asia/Dhaka';

-- Blood request status transitions and audit log.
create or replace function public.admin_update_blood_request(
  p_request_id uuid,
  p_new_status text,
  p_reason text default null
)
returns public.request_status
language plpgsql security definer set search_path = ''
as $$
declare
  v_actor uuid := auth.uid();
  v_old public.request_status;
  v_created_by uuid;
  v_new public.request_status;
  v_reason text := nullif(pg_catalog.btrim(coalesce(p_reason,'')),'');
begin
  if v_actor is null or not private.has_permission('requests.manage') then
    raise exception 'You do not have permission to manage blood requests';
  end if;
  if p_new_status not in ('live','closed','rejected') then raise exception 'Invalid request status'; end if;
  if p_new_status='rejected' and v_reason is null then raise exception 'Reject reason is required'; end if;

  select request_status,created_by into v_old,v_created_by
  from public.blood_requests where id=p_request_id for update;
  if not found then raise exception 'Blood request not found'; end if;

  v_new := p_new_status::public.request_status;
  if v_old='pending' and v_new not in ('live','rejected','closed') then raise exception 'Invalid transition'; end if;
  if v_old='live' and v_new not in ('closed') then raise exception 'Live request can only be closed'; end if;
  if v_old='closed' and v_new not in ('live') then raise exception 'Closed request can only be reopened'; end if;
  if v_old='rejected' then raise exception 'Rejected request cannot be changed'; end if;

  update public.blood_requests
  set request_status=v_new, reviewed_by=v_actor, reviewed_at=now()
  where id=p_request_id;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(v_actor,'blood_request.status_changed','blood_request',p_request_id::text,
    pg_catalog.jsonb_build_object('old_status',v_old,'new_status',v_new,'reason',v_reason));

  if v_created_by is not null then
    insert into public.notifications(user_id,title,body,notification_type)
    values(v_created_by,'Blood Request আপডেট',
      'আপনার Blood Request-এর বর্তমান অবস্থা: '||v_new::text||
      case when v_reason is not null then '। কারণ: '||v_reason else '' end,
      'blood_request');
  end if;
  return v_new;
end;
$$;
revoke all on function public.admin_update_blood_request(uuid,text,text) from public,anon;
grant execute on function public.admin_update_blood_request(uuid,text,text) to authenticated;

-- Send an in-app notification to an Auth-linked donor only.
create or replace function public.admin_send_notification(
  p_user_id uuid,
  p_title text,
  p_body text,
  p_notification_type text default 'admin_message'
)
returns uuid
language plpgsql security definer set search_path = ''
as $$
declare v_id uuid;
begin
  if auth.uid() is null or not private.has_permission('notifications.send') then
    raise exception 'You do not have permission to send notifications';
  end if;
  if p_title is null or pg_catalog.length(pg_catalog.btrim(p_title)) not between 2 and 120
     or p_body is null or pg_catalog.length(pg_catalog.btrim(p_body)) not between 2 and 1000 then
    raise exception 'Title (2-120) and message (2-1000) are required';
  end if;
  if not exists(select 1 from public.profiles where id=p_user_id) then
    raise exception 'Auth-linked recipient not found';
  end if;
  insert into public.notifications(user_id,title,body,notification_type)
  values(p_user_id,pg_catalog.btrim(p_title),pg_catalog.btrim(p_body),
    coalesce(nullif(pg_catalog.btrim(p_notification_type),''),'admin_message'))
  returning id into v_id;
  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(auth.uid(),'notification.sent','notification',v_id::text,
    pg_catalog.jsonb_build_object('recipient_user_id',p_user_id,'notification_type',p_notification_type));
  return v_id;
end;
$$;
revoke all on function public.admin_send_notification(uuid,text,text,text) from public,anon;
grant execute on function public.admin_send_notification(uuid,text,text,text) to authenticated;

-- Save/upsert site settings and record the change.
create or replace function public.admin_save_site_setting(
  p_setting_key text,
  p_setting_value jsonb,
  p_is_public boolean default false
)
returns void
language plpgsql security definer set search_path = ''
as $$
begin
  if auth.uid() is null or not private.has_permission('settings.manage') then
    raise exception 'You do not have permission to manage settings';
  end if;
  if p_setting_key is null or p_setting_key !~ '^[a-z][a-z0-9_.-]{1,79}$' then
    raise exception 'Invalid setting key';
  end if;
  if p_setting_value is null then raise exception 'Setting value is required'; end if;

  insert into public.site_settings(setting_key,setting_value,is_public,updated_by,updated_at)
  values(p_setting_key,p_setting_value,coalesce(p_is_public,false),auth.uid(),now())
  on conflict(setting_key) do update
  set setting_value=excluded.setting_value,is_public=excluded.is_public,
      updated_by=excluded.updated_by,updated_at=now();

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(auth.uid(),'site_setting.updated','site_setting',p_setting_key,
    pg_catalog.jsonb_build_object('is_public',coalesce(p_is_public,false)));
end;
$$;
revoke all on function public.admin_save_site_setting(text,jsonb,boolean) from public,anon;
grant execute on function public.admin_save_site_setting(text,jsonb,boolean) to authenticated;

commit;

-- After this migration, upload the matching admin.html.
-- This migration assumes kbh_public_donor_workflow.sql has completed successfully.
