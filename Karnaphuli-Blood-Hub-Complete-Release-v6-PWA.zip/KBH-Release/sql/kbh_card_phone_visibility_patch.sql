-- Karnaphuli Blood Hub | Donor ID Card phone visibility patch
-- Run once in Supabase SQL Editor before deploying the updated site.
-- Phone is returned only after matching the registered phone with the application/card number.
begin;

drop function if exists public.get_public_application_status(text,text);
create function public.get_public_application_status(
  p_application_number text,
  p_phone text
)
returns table(
  application_number text,
  donor_status text,
  full_name text,
  donor_code text,
  rejection_reason text,
  card_number text,
  qr_token uuid,
  blood_group text,
  district text,
  upazila text,
  area text,
  issued_at timestamptz,
  phone text
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_phone text := pg_catalog.regexp_replace(coalesce(p_phone,''), '[^0-9]', '', 'g');
begin
  if not private.allow_public_lookup(v_phone) then
    raise exception 'অনেকবার চেষ্টা করা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন';
  end if;

  return query
  select dp.application_number, dp.donor_status::text, dp.full_name, dp.donor_code,
         dp.rejection_reason, dc.card_number, dc.qr_token, dp.blood_group,
         dp.district, dp.upazila, dp.area, dc.issued_at, dp.phone
  from public.donor_profiles dp
  left join public.donor_cards dc on dc.donor_profile_id = dp.id and dc.revoked_at is null
  where pg_catalog.upper(dp.application_number) = pg_catalog.upper(pg_catalog.btrim(p_application_number))
    and pg_catalog.regexp_replace(coalesce(dp.phone,''), '[^0-9]', '', 'g') = v_phone
    and dp.user_id is null
  limit 1;
end;
$$;
revoke all on function public.get_public_application_status(text,text) from public, authenticated;
grant execute on function public.get_public_application_status(text,text) to anon, authenticated;

drop function if exists public.get_public_donor_card(text,text);
create function public.get_public_donor_card(
  p_card_number text,
  p_phone text
)
returns table(
  card_number text,
  qr_token uuid,
  full_name text,
  blood_group text,
  district text,
  upazila text,
  area text,
  issued_at timestamptz,
  phone text
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_phone text := pg_catalog.regexp_replace(coalesce(p_phone,''), '[^0-9]', '', 'g');
begin
  if not private.allow_public_lookup(v_phone) then
    raise exception 'অনেকবার চেষ্টা করা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন';
  end if;

  return query
  select dc.card_number, dc.qr_token, dp.full_name, dp.blood_group,
         dp.district, dp.upazila, dp.area, dc.issued_at, dp.phone
  from public.donor_cards dc
  join public.donor_profiles dp on dp.id = dc.donor_profile_id
  where pg_catalog.upper(dc.card_number) = pg_catalog.upper(pg_catalog.btrim(p_card_number))
    and pg_catalog.regexp_replace(coalesce(dp.phone,''), '[^0-9]', '', 'g') = v_phone
    and dp.donor_status = 'approved'
    and dc.revoked_at is null
    and dp.user_id is null
  limit 1;
end;
$$;
revoke all on function public.get_public_donor_card(text,text) from public, authenticated;
grant execute on function public.get_public_donor_card(text,text) to anon;

notify pgrst, 'reload schema';
commit;
