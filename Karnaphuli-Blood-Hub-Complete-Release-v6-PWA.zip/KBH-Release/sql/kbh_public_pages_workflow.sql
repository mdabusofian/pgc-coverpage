-- Karnaphuli Blood Hub | Public Pages Workflow Patch
-- Prerequisite: kbh_public_donor_workflow.sql and kbh_admin_modules.sql
-- Run once in Supabase SQL Editor. Public blood requests are submitted as Pending;
-- only Admin-approved (Live) requests appear in the public list.

begin;

-- Public donor list: never present an unverified self-reported last-donation date
-- as a verified donation. Only verified donation_records are used.
create or replace function public.get_public_donors()
returns table (
  donor_code text,
  full_name text,
  blood_group text,
  district text,
  upazila text,
  area text,
  gender text,
  donation_count_band text,
  last_donation_note text,
  last_donation_date date,
  contact_phone text
)
language sql
stable
security definer
set search_path = ''
as $$
  select dp.donor_code,
         coalesce(nullif(dp.full_name,''),p.full_name),
         dp.blood_group, dp.district, dp.upazila, dp.area, dp.gender,
         dp.donation_count_band,
         case when vd.last_verified_date is not null then 'যাচাইকৃত রক্তদান'::text else null::text end,
         vd.last_verified_date,
         case when dp.public_contact_consent then coalesce(dp.phone,p.phone) else null end
  from public.donor_profiles dp
  left join public.profiles p on p.id=dp.user_id
  left join lateral (
    select max(dr.donated_on) as last_verified_date
    from public.donation_records dr
    where dr.verification_status='verified'
      and (dr.donor_profile_id=dp.id or (dp.user_id is not null and dr.donor_user_id=dp.user_id))
  ) vd on true
  where dp.donor_status='approved' and dp.public_listing_consent=true
  order by dp.approved_at desc nulls last;
$$;
revoke all on function public.get_public_donors() from public;
grant execute on function public.get_public_donors() to anon, authenticated;

-- Public request submission. New requests are Pending and must be reviewed by Admin.
create or replace function public.submit_public_blood_request(
  p_blood_group text,
  p_units smallint,
  p_patient_name text,
  p_hospital text,
  p_district text,
  p_area text,
  p_contact_phone text,
  p_needed_by date,
  p_notes text default null,
  p_contact_public_consent boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_phone text := pg_catalog.regexp_replace(coalesce(p_contact_phone,''), '[^0-9]', '', 'g');
  v_id uuid;
begin
  if p_blood_group not in ('A+','A-','B+','B-','AB+','AB-','O+','O-') then
    raise exception 'সঠিক রক্তের গ্রুপ নির্বাচন করুন';
  end if;
  if p_units is null or p_units < 1 or p_units > 10 then
    raise exception '১ থেকে ১০ ব্যাগের মধ্যে পরিমাণ দিন';
  end if;
  if pg_catalog.length(pg_catalog.btrim(coalesce(p_patient_name,''))) < 2 then
    raise exception 'রোগীর নাম লিখুন';
  end if;
  if pg_catalog.length(pg_catalog.btrim(coalesce(p_hospital,''))) < 2 then
    raise exception 'হাসপাতালের নাম লিখুন';
  end if;
  if coalesce(pg_catalog.btrim(p_district),'')='' or coalesce(pg_catalog.btrim(p_area),'')='' then
    raise exception 'জেলা ও এলাকা পূরণ করুন';
  end if;
  if v_phone !~ '^01[0-9]{9}$' then
    raise exception 'সঠিক ১১ সংখ্যার বাংলাদেশি মোবাইল নম্বর দিন';
  end if;
  if p_needed_by is null or p_needed_by < current_date then
    raise exception 'আজ অথবা পরবর্তী তারিখ নির্বাচন করুন';
  end if;
  if coalesce(p_contact_public_consent,false) is not true then
    raise exception 'যোগাযোগের নম্বর প্রকাশের সম্মতি আবশ্যক';
  end if;
  if pg_catalog.length(coalesce(p_notes,'')) > 160 then
    raise exception 'অতিরিক্ত তথ্য ১৬০ অক্ষরের মধ্যে রাখুন';
  end if;
  if not private.allow_public_lookup(v_phone) then
    raise exception 'অনেকবার চেষ্টা করা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন';
  end if;

  insert into public.blood_requests(
    created_by,blood_group,units,patient_name,hospital,district,area,
    contact_phone,needed_by,notes,contact_public_consent,request_status
  ) values (
    null,p_blood_group,p_units,pg_catalog.btrim(p_patient_name),pg_catalog.btrim(p_hospital),
    pg_catalog.btrim(p_district),pg_catalog.btrim(p_area),v_phone,p_needed_by,
    nullif(pg_catalog.btrim(coalesce(p_notes,'')),''),true,'pending'
  ) returning id into v_id;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values (
    null,'blood_request.submitted','blood_request',v_id::text,
    pg_catalog.jsonb_build_object('source','public_form','blood_group',p_blood_group,'units',p_units,'district',pg_catalog.btrim(p_district),'area',pg_catalog.btrim(p_area))
  );

  return v_id;
end;
$$;
revoke all on function public.submit_public_blood_request(text,smallint,text,text,text,text,text,date,text,boolean) from public, authenticated;
grant execute on function public.submit_public_blood_request(text,smallint,text,text,text,text,text,date,text,boolean) to anon, authenticated;

-- Public read endpoint exposes only Live, non-expired requests with explicit
-- contact-publication consent. No direct anon table access is granted.
create or replace function public.get_public_blood_requests()
returns table (
  request_id uuid,
  blood_group text,
  units smallint,
  patient_name text,
  hospital text,
  district text,
  area text,
  contact_phone text,
  needed_by date,
  notes text,
  created_at timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  select br.id,br.blood_group,br.units,br.patient_name,br.hospital,
         br.district,br.area,br.contact_phone,br.needed_by,br.notes,br.created_at
  from public.blood_requests br
  where br.request_status='live'
    and br.contact_public_consent=true
    and br.needed_by >= current_date
  order by br.needed_by asc,br.created_at desc;
$$;
revoke all on function public.get_public_blood_requests() from public;
grant execute on function public.get_public_blood_requests() to anon, authenticated;


-- Rejected applications can be corrected and resubmitted by verifying the
-- original application number + previously registered mobile number.
create or replace function public.get_public_resubmission_data(
  p_application_number text,
  p_phone text
)
returns table (
  full_name text,
  phone text,
  blood_group text,
  district text,
  upazila text,
  area text,
  gender text,
  donation_count_band text,
  last_donation_date date,
  public_listing_consent boolean,
  public_contact_consent boolean
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_phone text := pg_catalog.regexp_replace(coalesce(p_phone,''), '[^0-9]', '', 'g');
begin
  if not private.allow_public_lookup(v_phone) then
    raise exception 'অনেকবার চেষ্টা করা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন';
  end if;
  return query
  select dp.full_name,dp.phone,dp.blood_group,dp.district,dp.upazila,dp.area,
         dp.gender,dp.donation_count_band,
         coalesce((select dr.donated_on from public.donation_records dr
                   where dr.donor_profile_id=dp.id and dr.verification_status='pending'
                     and dr.notes='Submitted during public donor registration'
                   order by dr.created_at desc limit 1),dp.last_donation_date),
         dp.public_listing_consent,dp.public_contact_consent
  from public.donor_profiles dp
  where pg_catalog.upper(dp.application_number)=pg_catalog.upper(pg_catalog.btrim(p_application_number))
    and pg_catalog.regexp_replace(coalesce(dp.phone,''),'[^0-9]','','g')=v_phone
    and dp.user_id is null and dp.donor_status='rejected'
  limit 1;
end;
$$;
revoke all on function public.get_public_resubmission_data(text,text) from public, authenticated;
grant execute on function public.get_public_resubmission_data(text,text) to anon, authenticated;

create or replace function public.resubmit_public_donor_application(
  p_application_number text,
  p_phone text,
  p_new_phone text,
  p_full_name text,
  p_blood_group text,
  p_district text,
  p_upazila text,
  p_area text,
  p_gender text,
  p_public_listing_consent boolean,
  p_public_contact_consent boolean,
  p_last_donation_date date,
  p_donation_count_band text,
  p_policy_consent boolean
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_old_phone text := pg_catalog.regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
  v_new_phone text := pg_catalog.regexp_replace(coalesce(p_new_phone,''),'[^0-9]','','g');
  v_profile_id uuid;
  v_application_number text;
begin
  if not private.allow_public_lookup(v_old_phone) then
    raise exception 'অনেকবার চেষ্টা করা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন';
  end if;
  if v_new_phone !~ '^01[0-9]{9}$' then raise exception 'সঠিক ১১ সংখ্যার বাংলাদেশি মোবাইল নম্বর দিন'; end if;
  if pg_catalog.length(pg_catalog.btrim(coalesce(p_full_name,''))) < 3 then raise exception 'নাম কমপক্ষে ৩ অক্ষরের হতে হবে'; end if;
  if p_blood_group not in ('A+','A-','B+','B-','AB+','AB-','O+','O-') then raise exception 'সঠিক রক্তের গ্রুপ নির্বাচন করুন'; end if;
  if coalesce(pg_catalog.btrim(p_district),'')='' or coalesce(pg_catalog.btrim(p_upazila),'')='' or coalesce(pg_catalog.btrim(p_area),'')='' then
    raise exception 'জেলা, উপজেলা ও এলাকা পূরণ করুন';
  end if;
  if coalesce(p_gender,'') not in ('Male','Female','Other') then raise exception 'লিঙ্গ নির্বাচন করুন'; end if;
  if p_public_contact_consent and not p_public_listing_consent then raise exception 'মোবাইল প্রকাশের সম্মতি দিতে হলে Public Listing সম্মতি চালু করতে হবে'; end if;
  if p_last_donation_date is not null and p_last_donation_date > current_date then raise exception 'ভবিষ্যতের রক্তদানের তারিখ দেওয়া যাবে না'; end if;
  if coalesce(p_donation_count_band,'') not in ('০','১-৩','৪-১০','১০+') then raise exception 'রক্তদানের সংখ্যা নির্বাচন করুন'; end if;
  if coalesce(p_policy_consent,false) is not true then raise exception 'নীতিমালায় সম্মতি আবশ্যক'; end if;

  select dp.id,dp.application_number into v_profile_id,v_application_number
  from public.donor_profiles dp
  where pg_catalog.upper(dp.application_number)=pg_catalog.upper(pg_catalog.btrim(p_application_number))
    and pg_catalog.regexp_replace(coalesce(dp.phone,''),'[^0-9]','','g')=v_old_phone
    and dp.user_id is null and dp.donor_status='rejected'
  for update;
  if v_profile_id is null then raise exception 'Rejected আবেদনটি পাওয়া যায়নি অথবা তথ্য মেলেনি'; end if;

  if exists(
    select 1 from public.donor_profiles dp
    where dp.id<>v_profile_id and dp.user_id is null
      and pg_catalog.regexp_replace(coalesce(dp.phone,''),'[^0-9]','','g')=v_new_phone
      and dp.donor_status in ('pending','approved','suspended')
  ) then raise exception 'এই মোবাইল নম্বর দিয়ে ইতিমধ্যে সক্রিয় আবেদন/ডোনার রেকর্ড রয়েছে'; end if;

  update public.donor_profiles
  set full_name=pg_catalog.btrim(p_full_name),phone=v_new_phone,blood_group=p_blood_group,
      district=pg_catalog.btrim(p_district),upazila=pg_catalog.btrim(p_upazila),area=pg_catalog.btrim(p_area),
      gender=p_gender,donation_count_band=p_donation_count_band,donor_status='pending',
      public_listing_consent=coalesce(p_public_listing_consent,false),
      public_contact_consent=coalesce(p_public_contact_consent,false),consent_recorded_at=now(),
      rejection_reason=null,approved_by=null,approved_at=null
  where id=v_profile_id;

  delete from public.donation_records
  where donor_profile_id=v_profile_id and verification_status='pending'
    and notes='Submitted during public donor registration';
  if p_last_donation_date is not null then
    insert into public.donation_records(donor_user_id,donor_profile_id,donated_on,notes,verification_status,submitted_by)
    values(null,v_profile_id,p_last_donation_date,'Submitted during public donor registration','pending',null);
  end if;

  insert into public.audit_logs(actor_user_id,action,entity_type,entity_id,details)
  values(null,'donor.application_resubmitted','donor_profile',v_profile_id::text,
    pg_catalog.jsonb_build_object('application_number',v_application_number,'source','public_resubmission'));

  return v_application_number;
end;
$$;
revoke all on function public.resubmit_public_donor_application(text,text,text,text,text,text,text,text,text,boolean,boolean,date,text,boolean) from public, authenticated;
grant execute on function public.resubmit_public_donor_application(text,text,text,text,text,text,text,text,text,boolean,boolean,date,text,boolean) to anon, authenticated;


-- Enforce the donor-registration policy consent on the database side as well.
-- The legacy 11-argument RPC is revoked from public clients; this 12-argument
-- wrapper validates consent and delegates to the existing validated workflow.
create or replace function public.submit_public_donor_application(
  p_full_name text,
  p_phone text,
  p_blood_group text,
  p_district text,
  p_upazila text,
  p_area text,
  p_gender text,
  p_public_listing_consent boolean,
  p_public_contact_consent boolean,
  p_last_donation_date date,
  p_donation_count_band text,
  p_policy_consent boolean
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
begin
  if coalesce(p_policy_consent,false) is not true then
    raise exception 'কর্ণফুলী ব্লাড হাবের নীতিমালায় সম্মতি আবশ্যক';
  end if;
  return public.submit_public_donor_application(
    p_full_name,p_phone,p_blood_group,p_district,p_upazila,p_area,p_gender,
    p_public_listing_consent,p_public_contact_consent,p_last_donation_date,p_donation_count_band
  );
end;
$$;
revoke all on function public.submit_public_donor_application(text,text,text,text,text,text,text,boolean,boolean,date,text) from public,anon,authenticated;
revoke all on function public.submit_public_donor_application(text,text,text,text,text,text,text,boolean,boolean,date,text,boolean) from public,authenticated;
grant execute on function public.submit_public_donor_application(text,text,text,text,text,text,text,boolean,boolean,date,text,boolean) to anon, authenticated;

-- Calendar-date validation must follow Bangladesh local time (Asia/Dhaka), not the database default UTC date.
ALTER FUNCTION public.submit_public_blood_request(text,smallint,text,text,text,text,text,date,text,boolean) SET timezone TO 'Asia/Dhaka';
ALTER FUNCTION public.resubmit_public_donor_application(text,text,text,text,text,text,text,text,text,boolean,boolean,date,text,boolean) SET timezone TO 'Asia/Dhaka';
ALTER FUNCTION public.submit_public_donor_application(text,text,text,text,text,text,text,boolean,boolean,date,text) SET timezone TO 'Asia/Dhaka';

-- Public lookups remain safe for a browser that already has an Admin session.
grant execute on function public.get_public_application_status(text,text) to anon, authenticated;
grant execute on function public.get_public_donor_card(text,text) to anon, authenticated;
grant execute on function public.verify_donor_by_token(uuid) to anon, authenticated;

notify pgrst, 'reload schema';

commit;
