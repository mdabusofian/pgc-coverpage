import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !anonKey || !serviceKey) {
    return json({ error: 'Server configuration is incomplete' }, 500);
  }

  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Authentication required' }, 401);

  const callerClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const adminClient = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: authData, error: authError } = await callerClient.auth.getUser();
  const caller = authData?.user;
  if (authError || !caller) return json({ error: 'Invalid or expired session' }, 401);

  try {
    const { data: roleRows, error: roleError } = await adminClient
      .from('user_roles').select('role').eq('user_id', caller.id);
    if (roleError) throw roleError;
    const role = roleRows?.[0]?.role;
    let allowed = role === 'admin' || role === 'super_admin';

    if (!allowed && role === 'staff') {
      const { data: permission, error: permissionError } = await adminClient
        .from('employee_permissions').select('permission_key')
        .eq('user_id', caller.id).eq('permission_key', 'staff.roles.manage').maybeSingle();
      if (permissionError) throw permissionError;
      allowed = !!permission;
    }
    if (!allowed) return json({ error: 'You do not have permission to invite staff' }, 403);

    let body: Record<string, unknown>;
    try { body = await req.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
    const email = String(body.email ?? '').trim().toLowerCase();
    const fullName = String(body.full_name ?? '').trim();
    const rawPhone = String(body.phone ?? '').replace(/[^0-9]/g, '');
    const phone = rawPhone || null;

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: 'সঠিক Email দিন' }, 400);
    if (fullName.length < 2 || fullName.length > 100) return json({ error: 'নাম ২–১০০ অক্ষরের মধ্যে হতে হবে' }, 400);
    if (phone && !/^01[0-9]{9}$/.test(phone)) return json({ error: 'সঠিক ১১ সংখ্যার মোবাইল নম্বর দিন' }, 400);

    const { data: inviteData, error: inviteError } = await adminClient.auth.admin.inviteUserByEmail(email, {
      data: { full_name: fullName, phone },
    });
    if (inviteError) throw inviteError;
    const invitedUser = inviteData.user;
    if (!invitedUser) throw new Error('Invite did not return a user');

    const { data: existingRows, error: existingError } = await adminClient
      .from('user_roles').select('role').eq('user_id', invitedUser.id);
    if (existingError) throw existingError;
    const existingRole = existingRows?.[0]?.role;
    if (existingRole === 'admin' || existingRole === 'super_admin') {
      return json({ error: 'এই Email ইতিমধ্যে elevated Admin account হিসেবে ব্যবহৃত হচ্ছে' }, 409);
    }

    const { error: roleUpsertError } = await adminClient.from('user_roles').upsert({
      user_id: invitedUser.id,
      role: 'staff',
      assigned_by: caller.id,
      assigned_at: new Date().toISOString(),
    }, { onConflict: 'user_id' });
    if (roleUpsertError) throw roleUpsertError;

    const { error: profileUpsertError } = await adminClient.from('profiles').upsert({
      id: invitedUser.id,
      full_name: fullName,
      phone,
    }, { onConflict: 'id' });
    if (profileUpsertError) throw profileUpsertError;

    const { error: auditError } = await adminClient.from('audit_logs').insert({
      actor_user_id: caller.id,
      action: 'staff.invited',
      entity_type: 'user',
      entity_id: invitedUser.id,
      details: { email, full_name: fullName, phone },
    });

    return json({ ok: true, user_id: invitedUser.id, email, audit_warning: auditError?.message ?? null, message: 'Staff invitation sent. Assign permissions before the staff member signs in.' });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Staff invitation failed';
    return json({ error: message }, 400);
  }
});
